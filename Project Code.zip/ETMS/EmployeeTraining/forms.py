# from django import forms
# from EmployeeTraining.models import EmployeeTraining
#
# class EmployeeFrom(forms.ModelForm):
#
#     class Meta:
#         model = EmployeeTraining