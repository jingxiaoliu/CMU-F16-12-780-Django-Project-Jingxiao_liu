connect casteel/tiger
SET ECHO ON
START C:\DBM\webDB\webDB.sql
SPOOL C:\DBM\webDB\webDBO.txt

SPOOL OUT
